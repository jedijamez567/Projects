﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Collections;

public class Hacker : MonoBehaviour
{
    // Game State
    int currentLevel;

    enum Screen { MainMenu, Password, Win };
    Screen currentScreen = Screen.MainMenu;

	// Use this for initialization
	void Start ()
    {
        //Login();
        ShowMainMenu();
        
	}
    
    // TODO create login and password screen
    
    void ShowMainMenu ()
    {
        currentScreen = Screen.MainMenu;
        Terminal.ClearScreen();
        //Terminal.WriteLine("Hello, " + username + ".");
        Terminal.WriteLine("What do you want to hack?");   
        Terminal.WriteLine("Press 1 for the Park's computer.");
        Terminal.WriteLine("Press 2 for your sister's computer.");
        Terminal.WriteLine("Press 3 to hack into my computer...");
        Terminal.WriteLine("Enter your selection: ");
    }


    void OnUserInput(string input)
    {
        if (input == "menu" || input == "exit")
        {
            ShowMainMenu();
        }
        else if (currentScreen == Screen.MainMenu)
        {
            RunMainMenu(input);
        }
        else if (currentScreen == Screen.Password)
        {
            CheckPassword(input);
        }
    }

    void CheckPassword(string input)
    {
        string password = "password";

        if(input == password)
        {
            Terminal.WriteLine("Correct!");
        }
        else
        {
            Terminal.WriteLine("Incorrect!");
        }
    }



    // Does things based on user input
    void RunMainMenu(string input)
    {
        if (input == "1" || input == "2" || input == "3")
        {
            for (int i = 0; i < input.Length; i++)
            {
                currentLevel = Convert.ToInt16(input);
                StartGame(input);
                currentScreen = Screen.Password;
                print("Current Level: " + currentLevel);
            }
        }
        else if (input == "007")
        {
            Terminal.WriteLine("Welcome Mr. Bond. Select a level.");
        }
        else if (input == "sudo")
        {
            Terminal.WriteLine("You win!!");
        }
        else
        {
            Terminal.WriteLine("Select a valid level.");
        }
    }

    void StartGame(string input)
    {
        Terminal.WriteLine("Welcome to Level " + currentLevel);
        Terminal.WriteLine("Please enter the password.");
    }
}
